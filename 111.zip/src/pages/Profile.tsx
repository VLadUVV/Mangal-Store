import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface UserProfile {
  fullName: string;
  phone: string;
  email: string;
}

export default function Profile() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({
    fullName: "John Doe",
    phone: "+1 234 567 890",
    email: "john@example.com"
  });
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
    toast({
      title: "С возвращением",
      description: "Вход успешно выполнен!"
    });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
    toast({
      title: "Добро пожаловать!",
      description: "Ваш аккаунт создан,спасибо!"
    });
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEditing(false);
    toast({
      title: "Профиль обновлён",
      description: "Your profile has been updated successfully."
    });
  };

  if (!isLoggedIn) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-8 text-mangal-600">Профиль</h1>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-semibold mb-4">Вход</h2>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label htmlFor="login-email">Email</Label>
                  <Input id="login-email" type="email" required />
                </div>
                <div>
                  <Label htmlFor="login-password">Пароль</Label>
                  <Input id="login-password" type="password" required />
                </div>
                <Button type="submit" className="w-full">Войти</Button>
              </form>
            </CardContent>
          </Card>

          <Dialog>
            <DialogTrigger asChild>
              <Card className="cursor-pointer hover:border-mangal-500 transition-colors">
                <CardContent className="pt-6">
                  <h2 className="text-xl font-semibold mb-4">Регистрация</h2>
                  <p className="text-gray-600 mb-4">Создайте новый аккаунт, чтобы начать покупки</p>
                  <Button variant="outline" className="w-full">Зарегистрироваться</Button>
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Создать аккаунт</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <Label htmlFor="register-name">ФИО</Label>
                  <Input id="register-name" required />
                </div>
                <div>
                  <Label htmlFor="register-phone">Номер телефона</Label>
                  <Input id="register-phone" type="tel" required />
                </div>
                <div>
                  <Label htmlFor="register-password">Пароль</Label>
                  <Input id="register-password" type="password" required />
                </div>
                <div>
                  <Label htmlFor="register-login">Email</Label>
                  <Input id="register-name" required />
                </div>
                <div>
                  <Label htmlFor="register-dob">Дата рождения</Label>
                  <Input id="register-dob" type="date" required />
                </div>
                <Button type="submit" className="w-full">Создать аккаунт</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-8 text-mangal-600">My Profile</h1>
      
      <Card className="max-w-2xl mx-auto">
        <CardContent className="pt-6">
          {isEditing ? (
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={profile.fullName}
                  onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                />
              </div>
              <div className="flex justify-between">
                <Button type="submit">Save Changes</Button>
                <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              <div>
                <Label className="block text-sm font-medium text-gray-500">Full Name</Label>
                <p className="mt-1 text-lg">{profile.fullName}</p>
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-500">Phone Number</Label>
                <p className="mt-1 text-lg">{profile.phone}</p>
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-500">Email</Label>
                <p className="mt-1 text-lg">{profile.email}</p>
              </div>
              <div className="flex justify-between">
                <Button onClick={() => setIsEditing(true)}>Edit Profile</Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsLoggedIn(false);
                    toast({
                      title: "Logged out",
                      description: "You have been logged out successfully."
                    });
                  }}
                >
                  Logout
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}